import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server-not-found',
  templateUrl: './server-not-found.component.html',
  styleUrls: ['./server-not-found.component.css']
})
export class ServerNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
