export interface SignIn {
    userid: string;
    password: string;
}
