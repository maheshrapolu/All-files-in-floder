import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-issues-search',
  templateUrl: './view-issues-search.component.html',
  styleUrls: ['./view-issues-search.component.css']
})
export class ViewIssuesSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
