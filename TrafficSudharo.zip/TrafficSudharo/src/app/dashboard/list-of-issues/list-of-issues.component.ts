import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-of-issues',
  templateUrl: './list-of-issues.component.html',
  styleUrls: ['./list-of-issues.component.css']
})
export class ListOfIssuesComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  totalIssue(){
    this.router.navigate(["/totalIssues"]);
  }
  approvedIssue(){
    this.router.navigate(["/approved"]);

  }
  pendingIssue(){
    this.router.navigate(["/Inventory"]);

  }
  rejected(){
  this.router.navigate(["approved"]);

 }
}
