import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-total-number-issues',
  templateUrl: './total-number-issues.component.html',
  styleUrls: ['./total-number-issues.component.css']
})
export class TotalNumberIssuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
