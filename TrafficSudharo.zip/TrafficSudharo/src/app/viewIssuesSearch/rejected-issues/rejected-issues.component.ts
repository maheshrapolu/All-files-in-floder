import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejected-issues',
  templateUrl: './rejected-issues.component.html',
  styleUrls: ['./rejected-issues.component.css']
})
export class RejectedIssuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
