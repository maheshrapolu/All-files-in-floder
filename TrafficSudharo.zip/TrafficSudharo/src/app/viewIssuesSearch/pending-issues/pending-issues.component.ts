import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-issues',
  templateUrl: './pending-issues.component.html',
  styleUrls: ['./pending-issues.component.css']
})
export class PendingIssuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
