import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approved-issues',
  templateUrl: './approved-issues.component.html',
  styleUrls: ['./approved-issues.component.css']
})
export class ApprovedIssuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
