
import { Component } from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.css']
})


export class AppComponent {
	title = 'Ojas Innovative Technologies';

	// Add few students for initial listing
	studentsList = [
	{	
		id : 1,
		first_name : "Venugopal",
		last_name : "Boddu",
		email : "venugopalboddu88@gmail.com",
		phone : 8897917920,
		department : "Science"
	},
	{
		id : 2,
		first_name : "Sujit",
		last_name : "Kumar",
		email : "sujit@gmail.com",
		phone : 8574889658,
		department : "Commerce"
	},
	{
		id : 3,
		first_name : "Akram",
		last_name : "Shaik",
		email : "akram@gmail.com",
		phone : 7485889658,
		department : "Science"
	},
	{
		id : 4,
		first_name : "Mahesh",
		last_name : "Doe",
		email : "mahesh@gmail.com",
		phone : 9685589748,
		department : "Arts"
	},
	{
		id : 5,
		first_name : "Sai",
		last_name : "Kumar",
		email : "saikumar@gmail.com",
		phone : 8595856547,
		department : "Engineering"
	}
	];

	constructor() {
		
		localStorage.setItem('students', JSON.stringify(this.studentsList));
	}
}

