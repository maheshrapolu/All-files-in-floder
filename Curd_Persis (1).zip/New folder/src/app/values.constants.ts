export enum TYPE {
    ERROR='error',
    SUCCESS='success',
    WARNING='warning',
    INFO='info',
    QUESTION='question'
  }